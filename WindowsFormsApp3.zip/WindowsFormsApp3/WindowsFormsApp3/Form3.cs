﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp3
{
    public partial class Form3 : Form
    {
        public static SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-J8GV74Q; Initial Catalog=Book Store FP; Integrated Security=True");

        public Form3()
        {
            InitializeComponent();
            
        }

        public void gridview()
        {
            
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Form3_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'book_Store_FPDataSet6.Customer' table. You can move, or remove it, as needed.
            this.customerTableAdapter.Fill(this.book_Store_FPDataSet6.Customer);
            
            // TODO: This line of code loads data into the 'book_Store_FPDataSet4.Publisher2' table. You can move, or remove it, as needed.
            this.publisher2TableAdapter.Fill(this.book_Store_FPDataSet4.Publisher2);
            // TODO: This line of code loads data into the 'book_Store_FPDataSet1.FormOfPayment' table. You can move, or remove it, as needed.
            this.formOfPaymentTableAdapter.Fill(this.book_Store_FPDataSet1.FormOfPayment);
            // TODO: This line of code loads data into the 'book_Store_FPDataSet.CustCategories' table. You can move, or remove it, as needed.
            this.custCategoriesTableAdapter.Fill(this.book_Store_FPDataSet.CustCategories);

            groupBox1.Enabled = false;
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();

            fill_grid();

        }

        public void fill_grid()
        {
          
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 frm2 = new Form2();
            frm2.Show();

        }

        private void button1_Click(object sender, EventArgs e)
        {
           groupBox1.Enabled = true;
            string FirstName = textBox1.Text;
            string LastName = textBox2.Text;
            string Phone = textBox3.Text;
            string Address = textBox4.Text;
            string custCategory = comboBox3.SelectedText;
            try
            {
                customerTableAdapter.Insert(FirstName, LastName, Phone, Address, custCategory);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Insert Failed");
            }
            RefreshDataSet();
        }
        private void RefreshDataSet()
        {
            this.customerTableAdapter.Fill(this.book_Store_FPDataSet6.Customer);
           // dataGridView1.datas
        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        

        private void button6_Click(object sender, EventArgs e)
        {
            groupBox1.Enabled = true;
            /*
            
            */
            //ambil data dari datagrid view masukin ke textbox

            //int selectedId = dataGridView1.Rows.GetRowCount(DataGridViewElementStates.Selected);
           // if (selectedId > 0)
          //  {
                
                
                textBox1.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                textBox2.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
                textBox3.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
                textBox4.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();

           

            //  }
            //string FirstName = textBox1.Text;
           /// string LastName = textBox2.Text;
           // string Phone = textBox3.Text;
            //string Address = textBox4.Text;
           /// string custCategory = comboBox3.SelectedText;


            // comboBox3.SelectedText = dataGridView1.SelectedRows[0].Cells[4].ToString();

            //
            // RefreshDataSet();
        }
       

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
           
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            string FirstName = textBox1.Text;
            string LastName = textBox2.Text;
            string Phone = textBox3.Text;
            string Address = textBox4.Text;
            string custCategory = comboBox3.SelectedText;
            SqlCommand cmd = new SqlCommand("update Customer set FirstName=@FirstName,LastName=@LastName,Phone=@Phone,Address=@Address,CustCategory=@CustCategory",con);
            cmd.Parameters.AddWithValue("@FirstName",textBox1.Text);
            cmd.Parameters.AddWithValue("@LastName",textBox2.Text);
            cmd.Parameters.AddWithValue("@Phone",textBox3.Text);
            cmd.Parameters.AddWithValue("@Address", textBox4.Text);
            cmd.Parameters.AddWithValue("@CustCategory", comboBox3.SelectedText);
            cmd.ExecuteNonQuery();
            RefreshDataSet();
            MessageBox.Show("Record Updated Successfully");


            try {
                customerTableAdapter.Update(book_Store_FPDataSet6.Customer);
              //   custCategoriesTableAdapter.Update()
                }
                 catch (Exception ex)
                  {
                      MessageBox.Show("Update Failed");
                 }

            }

            private void button5_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Form8 frm8 = new Form8();
            frm8.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            {
                
                SqlDataAdapter rdr = new SqlDataAdapter("Select * from Customer", con);
                SqlCommandBuilder cmdBuilder = new SqlCommandBuilder(rdr);
                DataSet dataset = new DataSet();
                SqlCommand cmd = new SqlCommand("delete from Customer where CustomerID=@CustomerID", rdr.SelectCommand.Connection);
                cmd.Parameters.Add(new SqlParameter("@CustomerID", SqlDbType.Int));
                cmd.Parameters["@CustomerID"].SourceVersion = DataRowVersion.Original;
                cmd.Parameters["@CustomerID"].SourceColumn = "CustomerID";
                rdr.DeleteCommand = cmd;
                rdr.Fill(dataset, "mydata");
                Console.WriteLine(cmdBuilder.GetDeleteCommand().CommandText);
                foreach (DataRow row in dataset.Tables["mydata"].Rows)
                {
                    row.Delete();
                }
                rdr.Update(dataset, "mydata");
               
            }
            RefreshDataSet();
        }

    

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
