﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp3
{
    public partial class Form4 : Form
    {
        public static SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-J8GV74Q; Initial Catalog=Book Store FP; Integrated Security=True");

        public Form4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Thank you for purchasing!");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form10 frm10 = new Form10();
            frm10.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form8 frm8 = new Form8();
            frm8.Show();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            groupBox1.Enabled = true;
            string Code  = textBox1.Text;
            DateTime Date = dateTimePicker1.MaxDate;
            string Customer = comboBox1.SelectedText;
            string Product = comboBox2.SelectedText;
            string Qty = textBox2.Text;
            string Cost = comboBox3.SelectedText;
            try
            {
                invoice3TableAdapter.Insert(Code,Date,Customer,Product,Qty,Cost);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Insert Failed");
            }
            RefreshDataSet();
        }
        private void RefreshDataSet()
        {
            this.invoice3TableAdapter.Fill(this.book_Store_FPDataSet12.Invoice3);
            // dataGridView1.datas
        }
        private void button2_Click_1(object sender, EventArgs e)
        {
            int sum = 0;
            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                sum += Convert.ToInt32(dataGridView1.Rows[i].Cells[3].Value);
            }
            int count_row = dataGridView1.Rows.Count;
            label7.Text = sum.ToString();
        }
        
        private void Form4_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'book_Store_FPDataSet15.Publisher2' table. You can move, or remove it, as needed.
            this.publisher2TableAdapter.Fill(this.book_Store_FPDataSet15.Publisher2);
            // TODO: This line of code loads data into the 'book_Store_FPDataSet14.Books5' table. You can move, or remove it, as needed.
            this.books5TableAdapter.Fill(this.book_Store_FPDataSet14.Books5);
            // TODO: This line of code loads data into the 'book_Store_FPDataSet13.CustCategories' table. You can move, or remove it, as needed.
            this.custCategoriesTableAdapter.Fill(this.book_Store_FPDataSet13.CustCategories);
            // TODO: This line of code loads data into the 'book_Store_FPDataSet12.Invoice3' table. You can move, or remove it, as needed.
            this.invoice3TableAdapter.Fill(this.book_Store_FPDataSet12.Invoice3);
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();

            fill_grid();

        }
        public void fill_grid()
        {

        }
        public void gridview()
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {
           
        }
    }
}
