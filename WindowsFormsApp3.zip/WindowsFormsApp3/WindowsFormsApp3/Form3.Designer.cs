﻿namespace WindowsFormsApp3
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.books3BindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.book_Store_FPDataSet5 = new WindowsFormsApp3.Book_Store_FPDataSet5();
            this.books3BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.publisher2BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.book_Store_FPDataSet4 = new WindowsFormsApp3.Book_Store_FPDataSet4();
            this.publisherBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.button2 = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.custCategoriesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.book_Store_FPDataSet = new WindowsFormsApp3.Book_Store_FPDataSet();
            this.custCategoryBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.custCategoryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label12 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.FirstName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LastName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Phone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Address = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CustCategory = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.book_Store_FPDataSet6 = new WindowsFormsApp3.Book_Store_FPDataSet6();
            this.orderBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.button6 = new System.Windows.Forms.Button();
            this.reggBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.formOfPaymentBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.book_Store_FPDataSet1 = new WindowsFormsApp3.Book_Store_FPDataSet1();
            this.formOfPaymentBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.custCategoriesTableAdapter = new WindowsFormsApp3.Book_Store_FPDataSetTableAdapters.CustCategoriesTableAdapter();
            this.button3 = new System.Windows.Forms.Button();
            this.formOfPaymentTableAdapter = new WindowsFormsApp3.Book_Store_FPDataSet1TableAdapters.FormOfPaymentTableAdapter();
            this.publisher2TableAdapter = new WindowsFormsApp3.Book_Store_FPDataSet4TableAdapters.Publisher2TableAdapter();
            this.books3TableAdapter = new WindowsFormsApp3.Book_Store_FPDataSet5TableAdapters.Books3TableAdapter();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.customerTableAdapter = new WindowsFormsApp3.Book_Store_FPDataSet6TableAdapters.CustomerTableAdapter();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.customerIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.books3BindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.book_Store_FPDataSet5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.books3BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.publisher2BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.book_Store_FPDataSet4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.publisherBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.custCategoriesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.book_Store_FPDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.custCategoryBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.custCategoryBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.book_Store_FPDataSet6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.reggBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.formOfPaymentBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.book_Store_FPDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.formOfPaymentBindingSource)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(900, 449);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(123, 55);
            this.button1.TabIndex = 0;
            this.button1.Text = "Add Data";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(49, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "First Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(49, 109);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Last Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(49, 173);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 20);
            this.label3.TabIndex = 3;
            this.label3.Text = "Phone";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(49, 247);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 20);
            this.label4.TabIndex = 4;
            this.label4.Text = "Address";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(93, 332);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 20);
            this.label5.TabIndex = 5;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(93, 402);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(0, 20);
            this.label6.TabIndex = 6;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(274, 34);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(281, 26);
            this.textBox1.TabIndex = 7;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(274, 103);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(281, 26);
            this.textBox2.TabIndex = 8;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(274, 167);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(281, 26);
            this.textBox3.TabIndex = 9;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(274, 247);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(281, 26);
            this.textBox4.TabIndex = 10;
            // 
            // books3BindingSource1
            // 
            this.books3BindingSource1.DataMember = "Books3";
            this.books3BindingSource1.DataSource = this.book_Store_FPDataSet5;
            // 
            // book_Store_FPDataSet5
            // 
            this.book_Store_FPDataSet5.DataSetName = "Book_Store_FPDataSet5";
            this.book_Store_FPDataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // books3BindingSource
            // 
            this.books3BindingSource.DataSource = typeof(WindowsFormsApp3.Books3);
            // 
            // publisher2BindingSource
            // 
            this.publisher2BindingSource.DataMember = "Publisher2";
            this.publisher2BindingSource.DataSource = this.book_Store_FPDataSet4;
            // 
            // book_Store_FPDataSet4
            // 
            this.book_Store_FPDataSet4.DataSetName = "Book_Store_FPDataSet4";
            this.book_Store_FPDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // publisherBindingSource
            // 
            this.publisherBindingSource.DataSource = typeof(WindowsFormsApp3.Publisher);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(737, 9);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(256, 47);
            this.button2.TabIndex = 19;
            this.button2.Text = "Log Out";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(51, 330);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(84, 20);
            this.label10.TabIndex = 20;
            this.label10.Text = "Profession";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(89, 9);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(189, 37);
            this.label11.TabIndex = 21;
            this.label11.Text = "Information";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // comboBox3
            // 
            this.comboBox3.DataSource = this.custCategoriesBindingSource;
            this.comboBox3.DisplayMember = "CustCategoriesName";
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(274, 322);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(168, 28);
            this.comboBox3.TabIndex = 22;
            this.comboBox3.ValueMember = "CustCategoriesID";
            this.comboBox3.SelectedIndexChanged += new System.EventHandler(this.comboBox3_SelectedIndexChanged);
            // 
            // custCategoriesBindingSource
            // 
            this.custCategoriesBindingSource.DataMember = "CustCategories";
            this.custCategoriesBindingSource.DataSource = this.book_Store_FPDataSet;
            // 
            // book_Store_FPDataSet
            // 
            this.book_Store_FPDataSet.DataSetName = "Book_Store_FPDataSet";
            this.book_Store_FPDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // custCategoryBindingSource1
            // 
            this.custCategoryBindingSource1.DataSource = typeof(WindowsFormsApp3.CustCategory);
            // 
            // custCategoryBindingSource
            // 
            this.custCategoryBindingSource.DataSource = typeof(WindowsFormsApp3.CustCategory);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(0, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(0, 20);
            this.label12.TabIndex = 23;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.customerIDDataGridViewTextBoxColumn,
            this.FirstName,
            this.LastName,
            this.Phone,
            this.Address,
            this.CustCategory});
            this.dataGridView1.DataSource = this.customerBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(61, 416);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(761, 393);
            this.dataGridView1.TabIndex = 31;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // FirstName
            // 
            this.FirstName.DataPropertyName = "FirstName";
            this.FirstName.HeaderText = "FirstName";
            this.FirstName.Name = "FirstName";
            // 
            // LastName
            // 
            this.LastName.DataPropertyName = "LastName";
            this.LastName.HeaderText = "LastName";
            this.LastName.Name = "LastName";
            // 
            // Phone
            // 
            this.Phone.DataPropertyName = "Phone";
            this.Phone.HeaderText = "Phone";
            this.Phone.Name = "Phone";
            // 
            // Address
            // 
            this.Address.DataPropertyName = "Address";
            this.Address.HeaderText = "Address";
            this.Address.Name = "Address";
            // 
            // CustCategory
            // 
            this.CustCategory.DataPropertyName = "CustCategory";
            this.CustCategory.HeaderText = "CustCategory";
            this.CustCategory.Name = "CustCategory";
            // 
            // customerBindingSource
            // 
            this.customerBindingSource.DataMember = "Customer";
            this.customerBindingSource.DataSource = this.book_Store_FPDataSet6;
            // 
            // book_Store_FPDataSet6
            // 
            this.book_Store_FPDataSet6.DataSetName = "Book_Store_FPDataSet6";
            this.book_Store_FPDataSet6.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // orderBindingSource
            // 
            this.orderBindingSource.DataSource = typeof(WindowsFormsApp3.Order);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(900, 541);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(123, 60);
            this.button6.TabIndex = 32;
            this.button6.Text = "Edit Data";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // reggBindingSource
            // 
            this.reggBindingSource.DataSource = typeof(WindowsFormsApp3.regg);
            // 
            // formOfPaymentBindingSource1
            // 
            this.formOfPaymentBindingSource1.DataMember = "FormOfPayment";
            this.formOfPaymentBindingSource1.DataSource = this.book_Store_FPDataSet1;
            // 
            // book_Store_FPDataSet1
            // 
            this.book_Store_FPDataSet1.DataSetName = "Book_Store_FPDataSet1";
            this.book_Store_FPDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // formOfPaymentBindingSource
            // 
            this.formOfPaymentBindingSource.DataSource = typeof(WindowsFormsApp3.FormOfPayment);
            // 
            // custCategoriesTableAdapter
            // 
            this.custCategoriesTableAdapter.ClearBeforeFill = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(900, 625);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(123, 55);
            this.button3.TabIndex = 34;
            this.button3.Text = "Delete Data";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // formOfPaymentTableAdapter
            // 
            this.formOfPaymentTableAdapter.ClearBeforeFill = true;
            // 
            // publisher2TableAdapter
            // 
            this.publisher2TableAdapter.ClearBeforeFill = true;
            // 
            // books3TableAdapter
            // 
            this.books3TableAdapter.ClearBeforeFill = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(842, 69);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(137, 60);
            this.button4.TabIndex = 35;
            this.button4.Text = "Save";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(842, 150);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(137, 54);
            this.button5.TabIndex = 36;
            this.button5.Text = "Cancel";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click_1);
            // 
            // customerTableAdapter
            // 
            this.customerTableAdapter.ClearBeforeFill = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button5);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.button4);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.textBox2);
            this.groupBox1.Controls.Add(this.comboBox3);
            this.groupBox1.Controls.Add(this.textBox3);
            this.groupBox1.Controls.Add(this.textBox4);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Location = new System.Drawing.Point(32, 55);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1021, 355);
            this.groupBox1.TabIndex = 37;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Info Data";
            // 
            // customerIDDataGridViewTextBoxColumn
            // 
            this.customerIDDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.customerIDDataGridViewTextBoxColumn.DataPropertyName = "CustomerID";
            this.customerIDDataGridViewTextBoxColumn.HeaderText = "CustomerID";
            this.customerIDDataGridViewTextBoxColumn.Name = "customerIDDataGridViewTextBoxColumn";
            this.customerIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1065, 830);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.button1);
            this.Name = "Form3";
            this.Text = "Menu Customer";
            this.Load += new System.EventHandler(this.Form3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.books3BindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.book_Store_FPDataSet5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.books3BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.publisher2BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.book_Store_FPDataSet4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.publisherBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.custCategoriesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.book_Store_FPDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.custCategoryBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.custCategoryBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.book_Store_FPDataSet6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.reggBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.formOfPaymentBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.book_Store_FPDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.formOfPaymentBindingSource)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.BindingSource custCategoryBindingSource;
        private System.Windows.Forms.BindingSource orderBindingSource;
        private System.Windows.Forms.BindingSource reggBindingSource;
        private System.Windows.Forms.BindingSource custCategoryBindingSource1;
        private System.Windows.Forms.BindingSource formOfPaymentBindingSource;
        private System.Windows.Forms.BindingSource books3BindingSource;
        private System.Windows.Forms.BindingSource publisherBindingSource;
        private Book_Store_FPDataSet book_Store_FPDataSet;
        private System.Windows.Forms.BindingSource custCategoriesBindingSource;
        private Book_Store_FPDataSetTableAdapters.CustCategoriesTableAdapter custCategoriesTableAdapter;
        private System.Windows.Forms.Button button3;
        private Book_Store_FPDataSet1 book_Store_FPDataSet1;
        private System.Windows.Forms.BindingSource formOfPaymentBindingSource1;
        private Book_Store_FPDataSet1TableAdapters.FormOfPaymentTableAdapter formOfPaymentTableAdapter;
        private Book_Store_FPDataSet4 book_Store_FPDataSet4;
        private System.Windows.Forms.BindingSource publisher2BindingSource;
        private Book_Store_FPDataSet4TableAdapters.Publisher2TableAdapter publisher2TableAdapter;
        private Book_Store_FPDataSet5 book_Store_FPDataSet5;
        private System.Windows.Forms.BindingSource books3BindingSource1;
        private Book_Store_FPDataSet5TableAdapters.Books3TableAdapter books3TableAdapter;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private Book_Store_FPDataSet6 book_Store_FPDataSet6;
        private System.Windows.Forms.BindingSource customerBindingSource;
        private Book_Store_FPDataSet6TableAdapters.CustomerTableAdapter customerTableAdapter;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridViewTextBoxColumn FirstName;
        private System.Windows.Forms.DataGridViewTextBoxColumn LastName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Phone;
        private System.Windows.Forms.DataGridViewTextBoxColumn Address;
        private System.Windows.Forms.DataGridViewTextBoxColumn CustCategory;
        private System.Windows.Forms.DataGridViewTextBoxColumn customerIDDataGridViewTextBoxColumn;
    }
}