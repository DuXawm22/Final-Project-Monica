﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 frm2 = new Form2();
            frm2.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
             string userName = textBox1.Text;
            string password = textBox2.Text;

           Book_Store_FPEntities2 lib = new Book_Store_FPEntities2();
            IQueryable<regg> loginQuery =
                from u in lib.reggs
                where u.id == userName && u.pass == password
                select u;

            List<regg> loggedUser = loginQuery.ToList<regg>();

            if (loggedUser.Count() == 1)
            {
                MessageBox.Show("Welcome!");
                Form3 frm3 = new Form3();
                frm3.Show();

            }
            else
            {
                MessageBox.Show("Please Enter the right Username and Password");
            }

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            Form2 frm2 = new Form2();
            frm2.Show();
        }
    }
}
