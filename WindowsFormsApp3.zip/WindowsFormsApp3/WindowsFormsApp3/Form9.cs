﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Collections;


namespace WindowsFormsApp3
{
    public partial class Form9 : Form
    {
        public static SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-J8GV74Q; Initial Catalog=Book Store FP; Integrated Security=True");
        public Form9()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form8 frm8 = new Form8();
            frm8.Show();
        }
        private void RefreshDataSet()
        {
            this.books5TableAdapter.Fill(this.book_Store_FPDataSet11.Books5);
            // dataGridView1.datas
        }

        private void button5_Click(object sender, EventArgs e)
        {
            groupBox1.Enabled = false;
            if (comboBox1.SelectedText != ""&& comboBox2.SelectedText !="")
            {
                SqlCommand cmd = new SqlCommand("delete Books5 where BookTitle=@BookTitle,Category=@Category,PublisherID=@PublisherID,Publisher=@Publisher,Qty=@Qty,Cost=@Cost)", con);

                cmd.Parameters.AddWithValue("@BookTitle", textBox5.Text);
                cmd.Parameters.AddWithValue("@Qty", textBox6.Text);
                cmd.Parameters.AddWithValue("@Cost", comboBox3.SelectedText);
                cmd.Parameters.AddWithValue("@Category", comboBox1.SelectedText);
                cmd.Parameters.AddWithValue("@Publisher", comboBox2.Text);
                cmd.Parameters.AddWithValue("@PublisherID", textBox2.Text);
                cmd.ExecuteNonQuery();
            }
            else
            {
                MessageBox.Show("Please Select Record to Delete");

            }

            RefreshDataSet();


        }

        private void Form9_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'book_Store_FPDataSet11.Books5' table. You can move, or remove it, as needed.
            this.books5TableAdapter.Fill(this.book_Store_FPDataSet11.Books5);
            // TODO: This line of code loads data into the 'book_Store_FPDataSet8.Publisher2' table. You can move, or remove it, as needed.
            this.publisher2TableAdapter.Fill(this.book_Store_FPDataSet8.Publisher2);

            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();

            fill_grid();

        }
        public void fill_grid()
        {

        }
        private void button4_Click(object sender, EventArgs e)
        {
            groupBox1.Enabled = true;
           
            /*
            
            */
            //ambil data dari datagrid view masukin ke textbox

            //int selectedId = dataGridView1.Rows.GetRowCount(DataGridViewElementStates.Selected);
            // if (selectedId > 0)
            //  {


            textBox5.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            comboBox1.SelectedText = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            comboBox2.SelectedText = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            textBox6.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();




            //  }
            //string FirstName = textBox1.Text;
            /// string LastName = textBox2.Text;
            // string Phone = textBox3.Text;
            //string Address = textBox4.Text;
            /// string custCategory = comboBox3.SelectedText;


            // comboBox3.SelectedText = dataGridView1.SelectedRows[0].Cells[4].ToString();

            //
            // RefreshDataSet();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            groupBox1.Enabled = true;
            {
                //string BookName = textBox5.Text;
                //string Category = comboBox1.SelectedText;
                //string Publisher = comboBox2.SelectedText;
                //int Qty = string.Parse(textBox6.Text);
                //int Cost = string.Parse(textBox1.Text);
                //try
                //{
                //    books5TableAdapter.Insert(BookName,Category,Publisher,Qty,Cost);
                //}
                //catch (Exception ex)
                //////{
                //   MessageBox.Show("Insert Failed");
                //}
                //RefreshDataSet();

                if (textBox5.Text != "" && textBox6.Text != "")
                {
                    SqlCommand cmd = new SqlCommand("insert into Books5(BookTitle,Category,PublisherID,Publisher,Qty,Cost) values(@BookTitle,@Category,@PublisherID,@Publisher,@Qty,@Cost)", con);
                   
                    cmd.Parameters.AddWithValue("@BookTitle", textBox5.Text);
                    cmd.Parameters.AddWithValue("@Qty", textBox6.Text);
                    cmd.Parameters.AddWithValue("@Cost", comboBox3.SelectedText);
                    cmd.Parameters.AddWithValue("@Category", comboBox1.SelectedText);
                    cmd.Parameters.AddWithValue("@Publisher", comboBox2.Text);
                    cmd.Parameters.AddWithValue("@PublisherID", textBox2.Text);
                    cmd.ExecuteNonQuery();
                   
                    MessageBox.Show("Record Inserted Successfully");
        
                }
                else
                {
                    MessageBox.Show("Please Provide Details!");
                }
                RefreshDataSet();
                
            }
            
        }
        
    }
}
