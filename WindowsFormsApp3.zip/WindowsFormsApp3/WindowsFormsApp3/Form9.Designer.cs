﻿namespace WindowsFormsApp3
{
    partial class Form9
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label14 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.publisher2BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.book_Store_FPDataSet8 = new WindowsFormsApp3.Book_Store_FPDataSet8();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.books5BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.book_Store_FPDataSet11 = new WindowsFormsApp3.Book_Store_FPDataSet11();
            this.books3BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.book_Store_FPDataSet7 = new WindowsFormsApp3.Book_Store_FPDataSet7();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.categoryDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BookTitle = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.costDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PublisherID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Publisher = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.books4BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.book_Store_FPDataSet10 = new WindowsFormsApp3.Book_Store_FPDataSet10();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.books3TableAdapter = new WindowsFormsApp3.Book_Store_FPDataSet7TableAdapters.Books3TableAdapter();
            this.publisher2TableAdapter = new WindowsFormsApp3.Book_Store_FPDataSet8TableAdapters.Publisher2TableAdapter();
            this.book_Store_FPDataSet9 = new WindowsFormsApp3.Book_Store_FPDataSet9();
            this.books3BindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.books3TableAdapter1 = new WindowsFormsApp3.Book_Store_FPDataSet9TableAdapters.Books3TableAdapter();
            this.books4TableAdapter = new WindowsFormsApp3.Book_Store_FPDataSet10TableAdapters.Books4TableAdapter();
            this.books5TableAdapter = new WindowsFormsApp3.Book_Store_FPDataSet11TableAdapters.Books5TableAdapter();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.publisher2BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.book_Store_FPDataSet8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.books5BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.book_Store_FPDataSet11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.books3BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.book_Store_FPDataSet7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.books4BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.book_Store_FPDataSet10)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.book_Store_FPDataSet9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.books3BindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(39, 96);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(92, 20);
            this.label14.TabIndex = 42;
            this.label14.Text = "Book Name";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(193, 96);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(299, 26);
            this.textBox5.TabIndex = 40;
            // 
            // comboBox2
            // 
            this.comboBox2.DataSource = this.publisher2BindingSource;
            this.comboBox2.DisplayMember = "PublisherName";
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(193, 213);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(196, 28);
            this.comboBox2.TabIndex = 37;
            this.comboBox2.ValueMember = "PublisherID";
            // 
            // publisher2BindingSource
            // 
            this.publisher2BindingSource.DataMember = "Publisher2";
            this.publisher2BindingSource.DataSource = this.book_Store_FPDataSet8;
            // 
            // book_Store_FPDataSet8
            // 
            this.book_Store_FPDataSet8.DataSetName = "Book_Store_FPDataSet8";
            this.book_Store_FPDataSet8.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // comboBox1
            // 
            this.comboBox1.DataSource = this.books5BindingSource;
            this.comboBox1.DisplayMember = "Category";
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(193, 155);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(196, 28);
            this.comboBox1.TabIndex = 36;
            this.comboBox1.ValueMember = "TitleID";
            // 
            // books5BindingSource
            // 
            this.books5BindingSource.DataMember = "Books5";
            this.books5BindingSource.DataSource = this.book_Store_FPDataSet11;
            // 
            // book_Store_FPDataSet11
            // 
            this.book_Store_FPDataSet11.DataSetName = "Book_Store_FPDataSet11";
            this.book_Store_FPDataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // books3BindingSource
            // 
            this.books3BindingSource.DataMember = "Books3";
            this.books3BindingSource.DataSource = this.book_Store_FPDataSet7;
            // 
            // book_Store_FPDataSet7
            // 
            this.book_Store_FPDataSet7.DataSetName = "Book_Store_FPDataSet7";
            this.book_Store_FPDataSet7.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(66, 213);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(74, 20);
            this.label8.TabIndex = 35;
            this.label8.Text = "Publisher";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(22, 155);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(118, 20);
            this.label7.TabIndex = 34;
            this.label7.Text = "Book Category ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(39, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(111, 37);
            this.label1.TabIndex = 44;
            this.label1.Text = "Books";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(792, 96);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(119, 48);
            this.button1.TabIndex = 45;
            this.button1.Text = "Save";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(792, 179);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(119, 54);
            this.button2.TabIndex = 46;
            this.button2.Text = "Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.categoryDataGridViewTextBoxColumn,
            this.BookTitle,
            this.costDataGridViewTextBoxColumn,
            this.PublisherID,
            this.Publisher});
            this.dataGridView1.DataSource = this.books5BindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(26, 334);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(709, 302);
            this.dataGridView1.TabIndex = 48;
            // 
            // categoryDataGridViewTextBoxColumn
            // 
            this.categoryDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.categoryDataGridViewTextBoxColumn.DataPropertyName = "Category";
            this.categoryDataGridViewTextBoxColumn.HeaderText = "Category";
            this.categoryDataGridViewTextBoxColumn.Name = "categoryDataGridViewTextBoxColumn";
            // 
            // BookTitle
            // 
            this.BookTitle.DataPropertyName = "BookTitle";
            this.BookTitle.HeaderText = "BookTitle";
            this.BookTitle.Name = "BookTitle";
            // 
            // costDataGridViewTextBoxColumn
            // 
            this.costDataGridViewTextBoxColumn.DataPropertyName = "Cost";
            this.costDataGridViewTextBoxColumn.HeaderText = "Cost";
            this.costDataGridViewTextBoxColumn.Name = "costDataGridViewTextBoxColumn";
            // 
            // PublisherID
            // 
            this.PublisherID.DataPropertyName = "PublisherID";
            this.PublisherID.HeaderText = "PublisherID";
            this.PublisherID.Name = "PublisherID";
            // 
            // Publisher
            // 
            this.Publisher.DataPropertyName = "Publisher";
            this.Publisher.HeaderText = "Publisher";
            this.Publisher.Name = "Publisher";
            // 
            // books4BindingSource
            // 
            this.books4BindingSource.DataMember = "Books4";
            this.books4BindingSource.DataSource = this.book_Store_FPDataSet10;
            // 
            // book_Store_FPDataSet10
            // 
            this.book_Store_FPDataSet10.DataSetName = "Book_Store_FPDataSet10";
            this.book_Store_FPDataSet10.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(193, 273);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(100, 26);
            this.textBox6.TabIndex = 41;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(107, 279);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(33, 20);
            this.label13.TabIndex = 39;
            this.label13.Text = "Qty";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(792, 379);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(119, 59);
            this.button3.TabIndex = 49;
            this.button3.Text = "Add";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(792, 462);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(119, 59);
            this.button4.TabIndex = 50;
            this.button4.Text = "Edit";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(792, 544);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(119, 63);
            this.button5.TabIndex = 51;
            this.button5.Text = "Delete";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.comboBox3);
            this.groupBox1.Controls.Add(this.textBox2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(12, 63);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(915, 255);
            this.groupBox1.TabIndex = 52;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Books Data";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(541, 158);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(97, 26);
            this.textBox2.TabIndex = 56;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(444, 158);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(91, 20);
            this.label3.TabIndex = 55;
            this.label3.Text = "PublisherID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(444, 213);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 20);
            this.label2.TabIndex = 53;
            this.label2.Text = "Cost";
            // 
            // books3TableAdapter
            // 
            this.books3TableAdapter.ClearBeforeFill = true;
            // 
            // publisher2TableAdapter
            // 
            this.publisher2TableAdapter.ClearBeforeFill = true;
            // 
            // book_Store_FPDataSet9
            // 
            this.book_Store_FPDataSet9.DataSetName = "Book_Store_FPDataSet9";
            this.book_Store_FPDataSet9.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // books3BindingSource1
            // 
            this.books3BindingSource1.DataMember = "Books3";
            this.books3BindingSource1.DataSource = this.book_Store_FPDataSet9;
            // 
            // books3TableAdapter1
            // 
            this.books3TableAdapter1.ClearBeforeFill = true;
            // 
            // books4TableAdapter
            // 
            this.books4TableAdapter.ClearBeforeFill = true;
            // 
            // books5TableAdapter
            // 
            this.books5TableAdapter.ClearBeforeFill = true;
            // 
            // comboBox3
            // 
            this.comboBox3.DataSource = this.publisher2BindingSource;
            this.comboBox3.DisplayMember = "Cost";
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(492, 210);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(200, 28);
            this.comboBox3.TabIndex = 57;
            this.comboBox3.ValueMember = "PublisherID";
            // 
            // Form9
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(949, 663);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form9";
            this.Text = "Form9";
            this.Load += new System.EventHandler(this.Form9_Load);
            ((System.ComponentModel.ISupportInitialize)(this.publisher2BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.book_Store_FPDataSet8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.books5BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.book_Store_FPDataSet11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.books3BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.book_Store_FPDataSet7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.books4BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.book_Store_FPDataSet10)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.book_Store_FPDataSet9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.books3BindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.GroupBox groupBox1;
        private Book_Store_FPDataSet7 book_Store_FPDataSet7;
        private System.Windows.Forms.BindingSource books3BindingSource;
        private Book_Store_FPDataSet7TableAdapters.Books3TableAdapter books3TableAdapter;
        private Book_Store_FPDataSet8 book_Store_FPDataSet8;
        private System.Windows.Forms.BindingSource publisher2BindingSource;
        private Book_Store_FPDataSet8TableAdapters.Publisher2TableAdapter publisher2TableAdapter;
        private Book_Store_FPDataSet9 book_Store_FPDataSet9;
        private System.Windows.Forms.BindingSource books3BindingSource1;
        private Book_Store_FPDataSet9TableAdapters.Books3TableAdapter books3TableAdapter1;
        private Book_Store_FPDataSet10 book_Store_FPDataSet10;
        private System.Windows.Forms.BindingSource books4BindingSource;
        private Book_Store_FPDataSet10TableAdapters.Books4TableAdapter books4TableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn categoryDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn BookTitle;
        private System.Windows.Forms.DataGridViewTextBoxColumn costDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn PublisherID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Publisher;
        private Book_Store_FPDataSet11 book_Store_FPDataSet11;
        private System.Windows.Forms.BindingSource books5BindingSource;
        private Book_Store_FPDataSet11TableAdapters.Books5TableAdapter books5TableAdapter;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBox3;
    }
}