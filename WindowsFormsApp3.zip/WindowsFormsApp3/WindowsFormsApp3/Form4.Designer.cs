﻿namespace WindowsFormsApp3
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.book_Store_FPDataSet12 = new WindowsFormsApp3.Book_Store_FPDataSet12();
            this.invoice3BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.invoice3TableAdapter = new WindowsFormsApp3.Book_Store_FPDataSet12TableAdapters.Invoice3TableAdapter();
            this.book_Store_FPDataSet13 = new WindowsFormsApp3.Book_Store_FPDataSet13();
            this.custCategoriesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.custCategoriesTableAdapter = new WindowsFormsApp3.Book_Store_FPDataSet13TableAdapters.CustCategoriesTableAdapter();
            this.book_Store_FPDataSet14 = new WindowsFormsApp3.Book_Store_FPDataSet14();
            this.books5BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.books5TableAdapter = new WindowsFormsApp3.Book_Store_FPDataSet14TableAdapters.Books5TableAdapter();
            this.codeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qtyDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.costDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label5 = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.book_Store_FPDataSet15 = new WindowsFormsApp3.Book_Store_FPDataSet15();
            this.publisher2BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.publisher2TableAdapter = new WindowsFormsApp3.Book_Store_FPDataSet15TableAdapters.Publisher2TableAdapter();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.book_Store_FPDataSet12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.invoice3BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.book_Store_FPDataSet13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.custCategoriesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.book_Store_FPDataSet14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.books5BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.book_Store_FPDataSet15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.publisher2BindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.codeDataGridViewTextBoxColumn,
            this.dateDataGridViewTextBoxColumn,
            this.customerDataGridViewTextBoxColumn,
            this.productsDataGridViewTextBoxColumn,
            this.qtyDataGridViewTextBoxColumn,
            this.costDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.invoice3BindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(54, 379);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(830, 523);
            this.dataGridView1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(50, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 20);
            this.label1.TabIndex = 3;
            this.label1.Text = "Code";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(50, 98);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 20);
            this.label2.TabIndex = 4;
            this.label2.Text = "Date";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(50, 162);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 20);
            this.label3.TabIndex = 5;
            this.label3.Text = "Customer";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(196, 38);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(214, 26);
            this.textBox1.TabIndex = 6;
            // 
            // comboBox1
            // 
            this.comboBox1.DataSource = this.custCategoriesBindingSource;
            this.comboBox1.DisplayMember = "CustCategoriesName";
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(196, 162);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(169, 28);
            this.comboBox1.TabIndex = 8;
            this.comboBox1.ValueMember = "CustCategoriesID";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(196, 98);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 26);
            this.dateTimePicker1.TabIndex = 48;
            // 
            // comboBox2
            // 
            this.comboBox2.DataSource = this.books5BindingSource;
            this.comboBox2.DisplayMember = "Category";
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(26, 46);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(207, 28);
            this.comboBox2.TabIndex = 49;
            this.comboBox2.ValueMember = "PublisherID";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(343, 22);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(33, 20);
            this.label4.TabIndex = 50;
            this.label4.Text = "Qty";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(665, 31);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(155, 56);
            this.button1.TabIndex = 51;
            this.button1.Text = "Add";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(179, 940);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(167, 48);
            this.button2.TabIndex = 52;
            this.button2.Text = "Save";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(597, 940);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(149, 48);
            this.button3.TabIndex = 53;
            this.button3.Text = "Cancel";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(277, 61);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(161, 26);
            this.textBox2.TabIndex = 54;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.textBox2);
            this.groupBox1.Controls.Add(this.comboBox3);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.comboBox2);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Location = new System.Drawing.Point(54, 236);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(851, 111);
            this.groupBox1.TabIndex = 55;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Product / Books";
            // 
            // book_Store_FPDataSet12
            // 
            this.book_Store_FPDataSet12.DataSetName = "Book_Store_FPDataSet12";
            this.book_Store_FPDataSet12.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // invoice3BindingSource
            // 
            this.invoice3BindingSource.DataMember = "Invoice3";
            this.invoice3BindingSource.DataSource = this.book_Store_FPDataSet12;
            // 
            // invoice3TableAdapter
            // 
            this.invoice3TableAdapter.ClearBeforeFill = true;
            // 
            // book_Store_FPDataSet13
            // 
            this.book_Store_FPDataSet13.DataSetName = "Book_Store_FPDataSet13";
            this.book_Store_FPDataSet13.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // custCategoriesBindingSource
            // 
            this.custCategoriesBindingSource.DataMember = "CustCategories";
            this.custCategoriesBindingSource.DataSource = this.book_Store_FPDataSet13;
            // 
            // custCategoriesTableAdapter
            // 
            this.custCategoriesTableAdapter.ClearBeforeFill = true;
            // 
            // book_Store_FPDataSet14
            // 
            this.book_Store_FPDataSet14.DataSetName = "Book_Store_FPDataSet14";
            this.book_Store_FPDataSet14.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // books5BindingSource
            // 
            this.books5BindingSource.DataMember = "Books5";
            this.books5BindingSource.DataSource = this.book_Store_FPDataSet14;
            // 
            // books5TableAdapter
            // 
            this.books5TableAdapter.ClearBeforeFill = true;
            // 
            // codeDataGridViewTextBoxColumn
            // 
            this.codeDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.codeDataGridViewTextBoxColumn.DataPropertyName = "Code";
            this.codeDataGridViewTextBoxColumn.HeaderText = "Code";
            this.codeDataGridViewTextBoxColumn.Name = "codeDataGridViewTextBoxColumn";
            // 
            // dateDataGridViewTextBoxColumn
            // 
            this.dateDataGridViewTextBoxColumn.DataPropertyName = "Date";
            this.dateDataGridViewTextBoxColumn.HeaderText = "Date";
            this.dateDataGridViewTextBoxColumn.Name = "dateDataGridViewTextBoxColumn";
            // 
            // customerDataGridViewTextBoxColumn
            // 
            this.customerDataGridViewTextBoxColumn.DataPropertyName = "Customer";
            this.customerDataGridViewTextBoxColumn.HeaderText = "Customer";
            this.customerDataGridViewTextBoxColumn.Name = "customerDataGridViewTextBoxColumn";
            // 
            // productsDataGridViewTextBoxColumn
            // 
            this.productsDataGridViewTextBoxColumn.DataPropertyName = "Products";
            this.productsDataGridViewTextBoxColumn.HeaderText = "Products";
            this.productsDataGridViewTextBoxColumn.Name = "productsDataGridViewTextBoxColumn";
            // 
            // qtyDataGridViewTextBoxColumn
            // 
            this.qtyDataGridViewTextBoxColumn.DataPropertyName = "Qty";
            this.qtyDataGridViewTextBoxColumn.HeaderText = "Qty";
            this.qtyDataGridViewTextBoxColumn.Name = "qtyDataGridViewTextBoxColumn";
            // 
            // costDataGridViewTextBoxColumn
            // 
            this.costDataGridViewTextBoxColumn.DataPropertyName = "Cost";
            this.costDataGridViewTextBoxColumn.HeaderText = "Cost";
            this.costDataGridViewTextBoxColumn.Name = "costDataGridViewTextBoxColumn";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(525, 22);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 20);
            this.label5.TabIndex = 55;
            this.label5.Text = "Price";
            // 
            // comboBox3
            // 
            this.comboBox3.DataSource = this.publisher2BindingSource;
            this.comboBox3.DisplayMember = "Cost";
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(465, 59);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(169, 28);
            this.comboBox3.TabIndex = 56;
            this.comboBox3.ValueMember = "PublisherID";
            // 
            // book_Store_FPDataSet15
            // 
            this.book_Store_FPDataSet15.DataSetName = "Book_Store_FPDataSet15";
            this.book_Store_FPDataSet15.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // publisher2BindingSource
            // 
            this.publisher2BindingSource.DataMember = "Publisher2";
            this.publisher2BindingSource.DataSource = this.book_Store_FPDataSet15;
            // 
            // publisher2TableAdapter
            // 
            this.publisher2TableAdapter.ClearBeforeFill = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(611, 49);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(236, 37);
            this.label6.TabIndex = 56;
            this.label6.Text = "Total Payment";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(662, 129);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(144, 20);
            this.label7.TabIndex = 57;
            this.label7.Text = "_______________";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(945, 1056);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form4";
            this.Text = "Invoice";
            this.Load += new System.EventHandler(this.Form4_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.book_Store_FPDataSet12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.invoice3BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.book_Store_FPDataSet13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.custCategoriesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.book_Store_FPDataSet14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.books5BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.book_Store_FPDataSet15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.publisher2BindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.GroupBox groupBox1;
        private Book_Store_FPDataSet12 book_Store_FPDataSet12;
        private System.Windows.Forms.BindingSource invoice3BindingSource;
        private Book_Store_FPDataSet12TableAdapters.Invoice3TableAdapter invoice3TableAdapter;
        private Book_Store_FPDataSet13 book_Store_FPDataSet13;
        private System.Windows.Forms.BindingSource custCategoriesBindingSource;
        private Book_Store_FPDataSet13TableAdapters.CustCategoriesTableAdapter custCategoriesTableAdapter;
        private Book_Store_FPDataSet14 book_Store_FPDataSet14;
        private System.Windows.Forms.BindingSource books5BindingSource;
        private Book_Store_FPDataSet14TableAdapters.Books5TableAdapter books5TableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn codeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn customerDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn productsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn qtyDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn costDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comboBox3;
        private Book_Store_FPDataSet15 book_Store_FPDataSet15;
        private System.Windows.Forms.BindingSource publisher2BindingSource;
        private Book_Store_FPDataSet15TableAdapters.Publisher2TableAdapter publisher2TableAdapter;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
    }
}